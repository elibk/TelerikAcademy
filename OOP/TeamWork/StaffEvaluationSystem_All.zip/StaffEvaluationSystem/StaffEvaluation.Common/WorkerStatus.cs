﻿////
namespace StaffEvaluation.Common
{
    using System;
    using System.Linq;

    public enum WorkerStatus
    {
        Normal = 0,
        ForPromotion = 1,
        ForDemotion = 2
    }
}
