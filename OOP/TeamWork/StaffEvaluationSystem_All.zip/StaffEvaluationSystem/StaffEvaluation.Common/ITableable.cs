﻿////
namespace StaffEvaluation.Common
{
    using System;
    using System.Linq;

    public interface ITableable
    {
        string ToTableView();
    }
}
